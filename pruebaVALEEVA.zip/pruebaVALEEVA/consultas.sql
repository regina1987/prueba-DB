SELECT clientes.name, facturas.total  FROM clientes INNER JOIN facturas ON clientes.id= facturas.id_cliente WHERE facturas.total IN (SELECT MAX(total) FROM facturas);
SELECT name from clientes WHERE id IN (SELECT id_cliente FROM facturas WHERE total>100) GROUP BY name;
SELECT COUNT(id_cliente) FROM facturas WHERE num IN(SELECT num_factura FROM compras WHERE id_productos=6) ;
