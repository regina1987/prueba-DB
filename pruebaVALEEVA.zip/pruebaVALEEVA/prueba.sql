--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6 (Ubuntu 11.6-1.pgdg18.04+1)
-- Dumped by pg_dump version 11.6 (Ubuntu 11.6-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: categorias; Type: TABLE; Schema: public; Owner: regiwa
--

CREATE TABLE public.categorias (
    id integer NOT NULL,
    nombre character varying(30),
    descripcion character varying(50)
);


ALTER TABLE public.categorias OWNER TO regiwa;

--
-- Name: clientes; Type: TABLE; Schema: public; Owner: regiwa
--

CREATE TABLE public.clientes (
    id integer NOT NULL,
    rut integer,
    name character varying(50),
    direccion character varying(100)
);


ALTER TABLE public.clientes OWNER TO regiwa;

--
-- Name: compras; Type: TABLE; Schema: public; Owner: regiwa
--

CREATE TABLE public.compras (
    num_factura integer,
    id_productos integer,
    candidad integer
);


ALTER TABLE public.compras OWNER TO regiwa;

--
-- Name: facturas; Type: TABLE; Schema: public; Owner: regiwa
--

CREATE TABLE public.facturas (
    num integer NOT NULL,
    id_cliente integer,
    fecha_compra date,
    sub_total integer,
    total double precision
);


ALTER TABLE public.facturas OWNER TO regiwa;

--
-- Name: productos; Type: TABLE; Schema: public; Owner: regiwa
--

CREATE TABLE public.productos (
    id integer NOT NULL,
    nombre character varying(30),
    descripcion character varying(50),
    precio integer,
    id_categoria integer
);


ALTER TABLE public.productos OWNER TO regiwa;

--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: regiwa
--

COPY public.categorias (id, nombre, descripcion) FROM stdin;
1	cafe	cafes de diferentes paises
2	te	te en hoja
3	cacao	polvo de cacao sin azucar
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: regiwa
--

COPY public.clientes (id, rut, name, direccion) FROM stdin;
1	111	Juan Perez	La Florida 124
2	222	Ana Acevedo	Huechuraba 56
3	333	Maria Ibañez	Santiago 156
4	444	Pedro Gonzalo	Las Condes 15
5	555	Carlos Riez	Vitacura 15
\.


--
-- Data for Name: compras; Type: TABLE DATA; Schema: public; Owner: regiwa
--

COPY public.compras (num_factura, id_productos, candidad) FROM stdin;
3	3	1
3	7	2
4	8	1
1	2	1
1	1	2
2	3	1
2	5	5
2	4	2
4	5	1
4	1	1
5	7	1
5	1	1
5	5	10
6	6	1
7	5	1
7	7	1
8	1	1
8	2	1
8	3	1
8	4	1
9	6	1
9	5	1
9	4	3
10	8	4
\.


--
-- Data for Name: facturas; Type: TABLE DATA; Schema: public; Owner: regiwa
--

COPY public.facturas (num, id_cliente, fecha_compra, sub_total, total) FROM stdin;
2	1	2020-01-16	900	1071
1	1	2020-01-16	4000	4076
3	2	2020-01-11	440	523.600000000000023
5	2	2020-01-18	2140	2546.59999999999991
6	3	2020-01-02	60	71.4000000000000057
7	4	2020-01-16	170	202.300000000000011
8	4	2020-01-12	3350	3986.5
9	4	2020-01-18	310	368.899999999999977
10	4	2020-01-17	320	380.800000000000011
4	2	2020-01-12	1180	1404.20000000000005
\.


--
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: regiwa
--

COPY public.productos (id, nombre, descripcion, precio, id_categoria) FROM stdin;
1	cafe arabico	en granos	1000	1
2	cafe de Kenia	en granos/molido	2000	1
3	cafe colombiano	en granos/molido/instantaneo	300	1
4	te blanco	Chino	50	2
5	te verde	con jasmine	100	2
6	te rojo	India	60	2
7	cacao de Kenia	cacao en polvo	70	3
8	cacao de Brazil	cacao en grano	80	3
\.


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: regiwa
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: regiwa
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: facturas facturas_pkey; Type: CONSTRAINT; Schema: public; Owner: regiwa
--

ALTER TABLE ONLY public.facturas
    ADD CONSTRAINT facturas_pkey PRIMARY KEY (num);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: regiwa
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- Name: compras compras_id_productos_fkey; Type: FK CONSTRAINT; Schema: public; Owner: regiwa
--

ALTER TABLE ONLY public.compras
    ADD CONSTRAINT compras_id_productos_fkey FOREIGN KEY (id_productos) REFERENCES public.productos(id);


--
-- Name: compras compras_num_factura_fkey; Type: FK CONSTRAINT; Schema: public; Owner: regiwa
--

ALTER TABLE ONLY public.compras
    ADD CONSTRAINT compras_num_factura_fkey FOREIGN KEY (num_factura) REFERENCES public.facturas(num);


--
-- Name: facturas facturas_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: regiwa
--

ALTER TABLE ONLY public.facturas
    ADD CONSTRAINT facturas_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.clientes(id);


--
-- Name: productos productos_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: regiwa
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categorias(id);


--
-- PostgreSQL database dump complete
--

